public class Polymorphism {
    public static void main (String[] arg) {
        double x = 2.5; // * Typecasting *
        // int 1 = x; // cannot convert from double to int
        int y = (int) x;
        System.out.println(y); // 2

        Base b = new Base();
        b.m(); // " Base"
        
        Derived d = new Derived();
        d.m(); // " Derived " 
        d.m1(); // " Derived1"
        
        Base b1 = new Derived(); //* UPcasting *
        b1.m(); // " Derived"
        
        // The method m1 () is undefined for the type Base
        // Fix: Explicit Downcasting syntax corrected below
        ((Derived) b1).m1(); // " Derived1" 
        
        // * Downcasting **
        // Derived b2 = new Base () ; // cannot convert from Base to Derived
        // Derived b2 = b1; // cannot convert from Base to Derived
        Derived b2 = (Derived) b1;
        b2.m(); // " Derived" 
        b2.m1(); // " Derived1"
    } // main
}

class Base {
    void m() { 
        System.out.println("Base"); 
    }
} // Base 

class Derived extends Base {
    void m() { 
        System.out.println("Derived"); 
    } 
    void m1() { 
        System.out.println("Derived1"); 
    }
} // Derived


